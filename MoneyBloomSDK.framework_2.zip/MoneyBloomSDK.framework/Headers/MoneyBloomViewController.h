//
//  BaseViewController.h
//  MoneyBloomSDK
//
//  Created by Amit Kumar Gupta on 01/08/19.
//  Copyright © 2019 Amit. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ProtocolDeclarations.h"

@interface MoneyBloomViewController : UIViewController <InitializationProtocol, MoneyBloomAuthInterface>

@property (readonly) id<MoneyBloomAuthenticator> authManager;

@end

