//
//  ProtocolDeclarations.h
//  testrnapp
//
//  Created by Amit Kumar Gupta on 03/08/19.
//  Copyright © 2019 Facebook. All rights reserved.
//

#ifndef ProtocolDeclarations_h
#define ProtocolDeclarations_h

@protocol InitializationProtocol <NSObject>

- (NSDictionary *) initialParams;

@end

@protocol MoneyBloomAuthenticator <NSObject>
- (void)authenticate:(BOOL)authenticated token:(NSString *)token;
@end

@protocol MoneyBloomAuthInterface <NSObject>

-(void)authenticatePayment:(NSString *)request;
-(void)heartbeatCallback;

@end
#endif /* ProtocolDeclarations_h */
